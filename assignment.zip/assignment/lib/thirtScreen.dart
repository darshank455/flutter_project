import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/percent_indicator.dart';

class ThirdScreen extends StatefulWidget {
  const ThirdScreen({super.key});

  @override
  State<ThirdScreen> createState() => _ThirdScreenState();
}

class _ThirdScreenState extends State<ThirdScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 16, 15, 15),
        body: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                height: height,
                width: width,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color.fromARGB(255, 41, 40, 40),
                      Color.fromARGB(255, 16, 15, 15),
                    ],
                  ),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 30,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.settings),
                            iconSize: 35,
                          ),
                          const Text(
                            'Artronic Earbuds',
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.list),
                            iconSize: 35,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      const Text(
                        "Victoria's iPhone",
                        style: TextStyle(color: Colors.white),
                      ),
                      const SizedBox(
                        height: 60,
                      ),
                      Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  height: 30,
                                ),
                                LinearPercentIndicator(
                                  animation: true,
                                  animationDuration: 1000,
                                  lineHeight: 10,
                                  percent: 0.7,
                                  progressColor:
                                      const Color.fromARGB(255, 53, 208, 226),
                                  width: 60,
                                  barRadius: const Radius.circular(10),
                                ),
                                Image.asset(
                                  'assets/left.png',
                                  width: 40,
                                  height: 40,
                                ),
                                const Text(
                                  '75%',
                                  style: TextStyle(color: Colors.white),
                                )
                              ],
                            ),
                            Expanded(
                              child: Image.asset('assets/budscase.png',
                                  width: 300, height: 300, fit: BoxFit.cover),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  height: 30,
                                ),
                                LinearPercentIndicator(
                                  animation: true,
                                  animationDuration: 1000,
                                  lineHeight: 10,
                                  percent: 0.6,
                                  progressColor:
                                      const Color.fromARGB(255, 53, 208, 226),
                                  width: 60,
                                  barRadius: const Radius.circular(10),
                                ),
                                Image.asset(
                                  'assets/right.png',
                                  width: 40,
                                  height: 40,
                                ),
                                const Text(
                                  '60%',
                                  style: TextStyle(color: Colors.white),
                                )
                              ],
                            ),
                          ]),
                      const SizedBox(
                        height: 20,
                      ),
                      LinearPercentIndicator(
                        alignment: MainAxisAlignment.center,
                        animation: true,
                        animationDuration: 1000,
                        lineHeight: 10,
                        percent: 0.7,
                        progressColor: const Color.fromARGB(255, 53, 208, 226),
                        width: 60,
                        barRadius: const Radius.circular(10),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const Text(
                        'Case 50%',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(
                        height: 60,
                      ),
                      const Text(
                        'Noise Control',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Container(
                        width: 325,
                        height: 75,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(35),
                          color: const Color.fromARGB(
                              255, 44, 49, 54), // Example color
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            TextButton(
                                onPressed: () {},
                                child: const Text(
                                  'Ambient\nAware',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.white),
                                )),
                            TextButton(
                                onPressed: () {},
                                child: const Text('Noise\nCancelling',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 53, 208, 226),
                                    ))),
                            TextButton(
                                onPressed: () {},
                                child: const Text('Talkthru',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: Colors.white)))
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: ClipPath(
          clipper: _SemiCircularClipper(),
          child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              color: const Color.fromARGB(255, 23, 22, 22),
              height: 75,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {},
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.white.withOpacity(0.5),
                            spreadRadius: 10,
                            blurRadius: 20,
                          ),
                        ],
                      ),
                      child: Image.asset(
                        'assets/bar2.png',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.bluetooth_audio_outlined),
                    iconSize: 40,
                  )
                ],
              )),
        ));
  }
}

class _SemiCircularClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    // Move to the starting point
    path.moveTo(0, 0);

    // Calculate the center of the container
    final center = size.width / 2;

    // Calculate the radius of the semi-circle
    final radius = size.width * 0.1;

    // Draw a straight line to the start of the semi-circle
    path.lineTo(center - radius, 0);

    // Draw the semi-circle arc
    path.arcToPoint(
      Offset(center + radius, 0),
      radius: Radius.circular(radius),
      clockwise: false,
    );

    // Draw a straight line to the end point
    path.lineTo(size.width, 0);

    // Draw lines to complete the rectangle
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close(); // Close the path to complete the shape

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
