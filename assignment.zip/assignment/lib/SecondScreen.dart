import 'package:assignment/thirtScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class SecondsScreen extends StatefulWidget {
  const SecondsScreen({super.key});

  @override
  _ScanningState createState() => _ScanningState();
}

class _ScanningState extends State<SecondsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool isphone = false;
  bool mac1 = false;
  bool watch = false;
  bool mac2 = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _animation = Tween<double>(begin: 0.9, end: 1).animate(_controller);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 16, 15, 15),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.fromARGB(255, 41, 40, 40),
                Color.fromARGB(255, 16, 15, 15),
              ],
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 50,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/image.png',
                      width: 300,
                      color: const Color.fromARGB(255, 230, 229, 225),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                AnimatedBuilder(
                  animation: _animation,
                  builder: (context, child) {
                    return CircularPercentIndicator(
                      radius: 100,
                      lineWidth: 20,
                      percent: _animation.value,
                      progressColor: const Color.fromARGB(255, 53, 208, 226),
                      circularStrokeCap: CircularStrokeCap.round,
                      center: ClipOval(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context)
                                .push(MaterialPageRoute(builder: (ctx) {
                              return const ThirdScreen();
                            }));
                          },
                          child: Image.asset(
                            'assets/bar2.png',
                            width: 110,
                            height: 200,
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(
                  height: 30,
                ),
                const Text(
                  'Connected to Victoria iphone',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'ALL DEVICES',
                  style: TextStyle(color: Colors.grey),
                  textAlign: TextAlign.start,
                ),
                Row(children: [
                  Expanded(
                      child: Card(
                    color: Colors.black38,
                    elevation: 5,
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context)
                            .push(MaterialPageRoute(builder: (ctx) {
                          return const ThirdScreen();
                        }));
                      },
                      borderRadius: BorderRadius.circular(15),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.phone_android,
                                  color: isphone
                                      ? const Color.fromARGB(255, 53, 208, 226)
                                      : Colors.white,
                                ),
                                IconButton(
                                    icon: Icon(
                                      isphone
                                          ? Icons.toggle_on
                                          : Icons.toggle_off,
                                      color: isphone ? Colors.green : null,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        isphone = !isphone;
                                      });
                                    }),
                              ],
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Victoria's iPhone",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 1),
                            isphone
                                ? const Text(
                                    'Connected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.green),
                                  )
                                : const Text(
                                    'Disconnected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.white),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  )),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: Card(
                    color: Colors.black38,
                    elevation: 5,
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: InkWell(
                      onTap: () {},
                      borderRadius: BorderRadius.circular(15),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.desktop_mac_outlined,
                                  color: mac1
                                      ? const Color.fromARGB(255, 53, 208, 226)
                                      : Colors.white,
                                ),
                                IconButton(
                                    icon: Icon(
                                      mac1 ? Icons.toggle_on : Icons.toggle_off,
                                      color: mac1 ? Colors.green : null,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        mac1 = !mac1;
                                      });
                                    }),
                              ],
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Victoria's Mac Book Pro",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 1),
                            mac1
                                ? const Text(
                                    'Connected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.green),
                                  )
                                : const Text(
                                    'Disconnected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.white),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  )),
                ]),
                Row(children: [
                  Expanded(
                      child: Card(
                    color: Colors.black38,
                    elevation: 5,
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: InkWell(
                      onTap: () {},
                      borderRadius: BorderRadius.circular(15),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.watch,
                                  color: watch
                                      ? const Color.fromARGB(255, 53, 208, 226)
                                      : Colors.white,
                                ),
                                IconButton(
                                    icon: Icon(
                                      watch
                                          ? Icons.toggle_on
                                          : Icons.toggle_off,
                                      color: watch ? Colors.green : null,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        watch = !watch;
                                      });
                                    }),
                              ],
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Victoria's Apple Watch",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 1),
                            watch
                                ? const Text(
                                    'Connected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.green),
                                  )
                                : const Text(
                                    'Disconnected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.white),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  )),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: Card(
                    color: Colors.black38,
                    elevation: 5,
                    margin: const EdgeInsets.all(10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: InkWell(
                      onTap: () {},
                      borderRadius: BorderRadius.circular(15),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(
                                  Icons.desktop_mac_outlined,
                                  color: mac2
                                      ? Color.fromARGB(255, 53, 208, 226)
                                      : Colors.white,
                                ),
                                IconButton(
                                    icon: Icon(
                                      mac2 ? Icons.toggle_on : Icons.toggle_off,
                                      color: mac2 ? Colors.green : null,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        mac2 = !mac2;
                                      });
                                    }),
                              ],
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Victoria's Mac Book Pro",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 1),
                            mac2
                                ? const Text(
                                    'Connected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.green),
                                  )
                                : const Text(
                                    'Disconnected',
                                    style: TextStyle(
                                        fontSize: 10, color: Colors.white),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  )),
                ]),
              ],
            ),
          ),
        ),
        bottomNavigationBar: ClipPath(
          clipper: _SemiCircularClipper(),
          child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              color: const Color.fromARGB(255, 23, 22, 22),
              height: 75,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {},
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.white
                                .withOpacity(0.5), // White color with opacity
                            spreadRadius:
                                10, // Spread radius for the glow effect
                            blurRadius: 20, // Blur radius for the glow effect
                          ),
                        ],
                      ),
                      child: Image.asset(
                        'assets/bar2.png',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.bluetooth_audio_outlined),
                    iconSize: 40,
                  )
                ],
              )),
        ));
    ;
  }
}

class _SemiCircularClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    // Move to the starting point
    path.moveTo(0, 0);

    // Calculate the center of the container
    final center = size.width / 2;

    // Calculate the radius of the semi-circle
    final radius = size.width * 0.1;

    // Draw a straight line to the start of the semi-circle
    path.lineTo(center - radius, 0);

    // Draw the semi-circle arc
    path.arcToPoint(
      Offset(center + radius, 0),
      radius: Radius.circular(radius),
      clockwise: false,
    );

    // Draw a straight line to the end point
    path.lineTo(size.width, 0);

    // Draw lines to complete the rectangle
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close(); // Close the path to complete the shape

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
