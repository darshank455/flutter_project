import 'package:assignment/SecondScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class Scanning extends StatefulWidget {
  const Scanning({super.key});

  @override
  _ScanningState createState() => _ScanningState();
}

class _ScanningState extends State<Scanning>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _animation = Tween<double>(begin: 0, end: 0.8).animate(_controller);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color.fromARGB(255, 36, 34, 34),
        body: SingleChildScrollView(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color.fromARGB(255, 41, 40, 40),
                  Color.fromARGB(255, 16, 15, 15),
                ],
              ),
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  Image.asset(
                    'assets/image.png',
                    color: const Color.fromARGB(255, 230, 229, 225),
                    height: 200,
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  const Text(
                    'Searching Devices...',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  AnimatedBuilder(
                    animation: _animation,
                    builder: (context, child) {
                      return CircularPercentIndicator(
                        radius: 120,
                        lineWidth: 20,
                        percent: _animation.value,
                        progressColor: const Color.fromARGB(255, 53, 208, 226),
                        circularStrokeCap: CircularStrokeCap.round,
                        center: ClipOval(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          child: Image.asset(
                            'assets/buds.png',
                            width: 200,
                            height: 200,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  IconButton(
                    tooltip: 'Next Page',
                    iconSize: 50,
                    color: const Color.fromARGB(255, 35, 216, 237),
                    onPressed: () {
                      Navigator.of(context)
                          .push(MaterialPageRoute(builder: (ctx) {
                        return SecondsScreen();
                      }));
                    },
                    icon: Stack(
                      alignment: Alignment.center,
                      children: [
                        const Icon(Icons.bluetooth_audio_sharp),
                        Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                          ),
                          width: 50,
                          height: 50,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: ClipPath(
          clipper: _SemiCircularClipper(),
          child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              color: const Color.fromARGB(255, 23, 22, 22),
              height: 75,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {},
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                      ),
                      child: Image.asset(
                        'assets/bar2.png',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                ],
              )),
        ));
    ;
  }
}

class _SemiCircularClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    // Move to the starting point
    path.moveTo(0, 0);

    // Calculate the center of the container
    final center = size.width / 2;

    // Calculate the radius of the semi-circle
    final radius = size.width * 0.1;

    // Draw a straight line to the start of the semi-circle
    path.lineTo(center - radius, 0);

    // Draw the semi-circle arc
    path.arcToPoint(
      Offset(center + radius, 0),
      radius: Radius.circular(radius),
      clockwise: false,
    );

    // Draw a straight line to the end point
    path.lineTo(size.width, 0);

    // Draw lines to complete the rectangle
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close(); // Close the path to complete the shape

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}
